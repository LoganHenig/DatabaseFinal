package bo;

import java.io.Serializable;
import java.util.Comparator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@SuppressWarnings("serial")
@Entity(name = "playerteamseason")
public class PlayerTeamSeason implements Serializable {

	@EmbeddedId
	PlayerTeamSeasonId id;

	@Embeddable
	static class PlayerTeamSeasonId implements Serializable {
		@ManyToOne
		@JoinColumn(name = "playerid", referencedColumnName = "playerid", insertable = false, updatable = false)
		Player player;
		@Column(name="year")
		Integer playerYear;
        public Integer playerYearId;
		@Override
		public boolean equals(Object obj) {
			if(!(obj instanceof PlayerTeamSeasonId)){
				return false;
			}
			PlayerTeamSeasonId other = (PlayerTeamSeasonId)obj;
			// in order for two different object of this type to be equal,
			// they must be for the same year and for the same player
			return (this.player==other.player &&
					this.playerYear==other.playerYear);
		}
		 
		@Override
		public int hashCode() {
			Integer hash = 0;
			if (this.player != null) hash += this.player.hashCode();
			if (this.playerYear != null) hash += this.playerYear.hashCode();
			return hash;
		}
	}

	@Column
	String playerID;
	@Column
    String teamID;
    @Column
    Integer yearID;

	
	// Hibernate needs a default constructor
	public PlayerTeamSeason() {}
	
	public PlayerTeamSeason(Player p, Integer year) {
		PlayerTeamSeasonId ptsi = new PlayerTeamSeasonId();
		ptsi.player = p;
		ptsi.playerYear = year;
		this.id = ptsi;
	}
	
	public void setYearID(Integer year) {
		this.id.playerYearId = year;
	}

	public Integer getYear() {
		return this.id.playerYearId;
	}

	public String getPlayerID() {
		return this.playerID;
	}

	public void setPlayerID(String id) {
		this.playerID = id;
	}

    public void setTeamID(String id) {
        this.teamID = id;
    }

    public String getTeamID() {
        return this.teamID;
    }

	/*
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof PlayerSeason)){
			return false;
		}
		PlayerSeason other = (PlayerSeason)obj;
		return other.getId().equals(this.getId());
	}
	 */
    public PlayerTeamSeasonId getId() {
		return this.id;
	}

	@Override
	public int hashCode() {
		return this.getId().hashCode();
	}

	public static Comparator<PlayerSeason> playerSeasonsComparator = new Comparator<PlayerSeason>() {

		public int compare(PlayerSeason ps1, PlayerSeason ps2) {
			Integer year1 = ps1.getYear();
			Integer year2 = ps2.getYear();
			return year1.compareTo(year2);
		}

	};
	
}
