package controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;



import view.TeamView;
import bo.Team;
import bo.TeamSeason;
import bo.Player;
import bo.PlayerSeason;
import dataaccesslayer.HibernateUtil;

public class PlayerTeamController extends BaseController {

    @Override
    public void init(String query) {
        System.out.println("building dynamic html for player-team season");
        view = new PlayerTeamView();
        process(query);
    }

    @Override
    protected void performAction() [
        String action = keyVals.
    ]
}

